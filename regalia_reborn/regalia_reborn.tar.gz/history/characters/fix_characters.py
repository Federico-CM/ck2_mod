import re

INPUT_FILE = "characters.txt"
OUTPUT_FILE = "characters2.txt"
ENCODING = "cp1252"  # CK2-friendly, not UTF-8


CHARACTER_START_RE = re.compile(r"^\s*\d+\s*=\s*\{\s*(#.*)?$")
DATED_BLOCK_RE = re.compile(r"^\s*\d+\.\d+\.\d+\s*=\s*\{\s*(#.*)?$")


def count_braces_outside_quotes(line: str) -> int:
    """
    Count net brace change in a line, ignoring braces inside quoted strings.
    """
    depth_change = 0
    in_string = False
    escaped = False

    for ch in line:
        if ch == "\\" and in_string:
            escaped = not escaped
            continue

        if ch == '"' and not escaped:
            in_string = not in_string
        elif not in_string:
            if ch == "{":
                depth_change += 1
            elif ch == "}":
                depth_change -= 1

        if ch != "\\":
            escaped = False

    return depth_change


def split_top_level_entries(block_lines):
    """
    Given the inside of a character block (everything after the opening line
    and before the closing line), split it into top-level entries.

    A top-level entry is either:
    - a simple assignment line
    - a blank line
    - a top-level nested block such as 268.1.1 = { ... }
    """
    entries = []
    current = []
    nested_depth = 0

    for line in block_lines:
        if nested_depth == 0:
            # If we're not currently inside a nested block, blank lines become
            # standalone entries so spacing is preserved better.
            if not current and line.strip() == "":
                entries.append([line])
                continue

        current.append(line)
        nested_depth += count_braces_outside_quotes(line)

        if nested_depth == 0:
            entries.append(current)
            current = []

    # In case of malformed input, keep whatever remains
    if current:
        entries.append(current)

    return entries


def is_dated_entry(entry_lines):
    """
    Return True if this top-level entry is a dated block like:
        268.1.1 = {
            birth = 268.1.1
        }
    """
    if not entry_lines:
        return False

    first_nonblank = None
    for line in entry_lines:
        if line.strip():
            first_nonblank = line
            break

    if first_nonblank is None:
        return False

    # Must start like a dated block and contain braces overall
    if not DATED_BLOCK_RE.match(first_nonblank):
        return False

    total_braces = sum(count_braces_outside_quotes(line) for line in entry_lines)
    return total_braces == 0


def normalize_spacing_before_events(non_event_entries, event_entries):
    """
    Keep formatting readable:
    - strip trailing blank lines from the non-event section
    - ensure exactly one blank line before moved event blocks if both sections exist
    """
    while non_event_entries and all(not line.strip() for line in non_event_entries[-1]):
        non_event_entries.pop()

    result = list(non_event_entries)

    if result and event_entries:
        result.append(["\n"])

    result.extend(event_entries)
    return result


def process_character_block(block_lines):
    """
    Reorder a full character block.

    block_lines includes:
    - opening line: 4 = {
    - body lines
    - closing line: }
    """
    if len(block_lines) < 2:
        return block_lines

    opening_line = block_lines[0]
    closing_line = block_lines[-1]
    body_lines = block_lines[1:-1]

    entries = split_top_level_entries(body_lines)

    non_event_entries = []
    event_entries = []

    for entry in entries:
        if is_dated_entry(entry):
            event_entries.append(entry)
        else:
            non_event_entries.append(entry)

    reordered_entries = normalize_spacing_before_events(non_event_entries, event_entries)

    new_block = [opening_line]
    for entry in reordered_entries:
        new_block.extend(entry)
    new_block.append(closing_line)

    return new_block


def process_file(lines):
    """
    Process the whole file and reorder dated event blocks inside top-level character blocks.
    """
    output = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        if CHARACTER_START_RE.match(line):
            block = [line]
            depth = count_braces_outside_quotes(line)
            i += 1

            while i < n and depth > 0:
                block.append(lines[i])
                depth += count_braces_outside_quotes(lines[i])
                i += 1

            output.extend(process_character_block(block))
        else:
            output.append(line)
            i += 1

    return output


def main():
    with open(INPUT_FILE, "r", encoding=ENCODING, newline="") as f:
        lines = f.readlines()

    fixed_lines = process_file(lines)

    with open(OUTPUT_FILE, "w", encoding=ENCODING, newline="") as f:
        f.writelines(fixed_lines)

    print(f"Done. Fixed file saved as {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
